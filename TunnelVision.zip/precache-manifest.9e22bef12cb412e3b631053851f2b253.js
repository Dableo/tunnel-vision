self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "99574b31d23684184a792b2dedd9b819",
    "url": "/index.html"
  },
  {
    "revision": "6d9bdd59c6bb819ec0ee",
    "url": "/static/js/2.b6a09587.chunk.js"
  },
  {
    "revision": "eb56b19eba63a53416f4fd778023529f",
    "url": "/static/js/2.b6a09587.chunk.js.LICENSE.txt"
  },
  {
    "revision": "379396e56f393a61f040",
    "url": "/static/js/main.1857afb0.chunk.js"
  },
  {
    "revision": "9f0cc0e4289919c35d4a",
    "url": "/static/js/runtime-main.b1aab91f.js"
  },
  {
    "revision": "3785c6d320751f9dd86816b53a990c65",
    "url": "/static/media/grave.3785c6d3.svg"
  },
  {
    "revision": "a87290349245ba823806e78b6b92a6c8",
    "url": "/static/media/skeleton.a8729034.svg"
  },
  {
    "revision": "e6ea662a24f38ef2f870f70729509fa3",
    "url": "/static/media/warrior.e6ea662a.svg"
  },
  {
    "revision": "3366f1062c4f991501fb7ebb671c0434",
    "url": "/static/media/wizard.3366f106.svg"
  }
]);